package com.sda.medicalspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
