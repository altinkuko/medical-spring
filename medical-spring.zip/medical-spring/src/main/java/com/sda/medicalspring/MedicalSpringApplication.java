package com.sda.medicalspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalSpringApplication.class, args);
	}

}
