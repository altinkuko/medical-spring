package com.sda.medicalspring.static_data;

public enum Status {
    COMPLETED,
    CANCELED,
    CREATED
}
