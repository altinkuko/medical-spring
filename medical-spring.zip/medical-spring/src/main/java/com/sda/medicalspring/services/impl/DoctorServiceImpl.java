package com.sda.medicalspring.services.impl;

import com.sda.medicalspring.entities.Doctor;
import com.sda.medicalspring.repositories.DoctorRepository;
import com.sda.medicalspring.services.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DoctorServiceImpl implements DoctorService {
    @Autowired
    private DoctorRepository doctorRepository;

    @Override
    public Doctor create(Doctor doctor){
        if (doctor.getDoctorId() == null) {
            return doctorRepository.save(doctor);
        } else {
            return null;
        }
    }
    @Override
    public Doctor update(Doctor doctor){
        if (doctor.getDoctorId() != null) {
            return doctorRepository.save(doctor);
        } else {
            return null;
        }
    }
    @Override
    public List<Doctor> findAll(){
        return doctorRepository.findAll();
    }
    @Override
    public Doctor findById(Long id){
        return doctorRepository.findById(id).orElse(null);
    }
    @Override
    public void delete(Long id){
        doctorRepository.deleteById(id);
    }
    @Override
    public List<Doctor> findAllBySpecialization(String specialization){
        return doctorRepository.findBySpecialization(specialization);
    }
}
